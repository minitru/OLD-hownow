#!/bin/sh
#
# bbinc-client.sh
#
# (c) Copyright Quest Software, Inc. 1997-2009 - All Rights Reserved.
#

BBDFTAB="${BBHOME}/etc/bb-dftab"	# LEVELS BY DISK PARTITION
BBCPUTAB="${BBHOME}/etc/bb-cputab"	# LEVELS BY DISK PARTITION
BBPROCTAB="${BBHOME}/etc/bb-proctab"	# LEVELS BY DISK PARTITION
BBMSGSTAB="${BBHOME}/etc/bb-msgstab"	# MSGS KEYWORDS/PHRASES TO CHECK
export BBDFTAB BBCPUTAB BBPROCTAB BBMSGSTAB
