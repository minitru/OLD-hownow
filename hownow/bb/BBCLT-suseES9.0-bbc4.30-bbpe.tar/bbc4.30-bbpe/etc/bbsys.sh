#!/bin/sh
#
# bbsys.sh
#
# Sean MacGuire
#
# (c) Copyright Quest Software, Inc. 1997-2009 - All Rights Reserved.
#
# BIG BROTHER
# WHERE THINGS WE NEED LIVE...
#

#
# STANDARD COMMANDS...
#
NSLOOKUP="/usr/bin/nslookup"		# SMM NEW IN 1.06C
PING="/sbin/ping"			# CONNECTIVITY TEST
LS="/bin/ls"
FIND="/usr/bin/find"
TOUCH="/usr/bin/touch"
CAT="/bin/cat"
GREP="/usr/bin/grep"
SORT="/usr/bin/sort"
UNIQ="/usr/bin/uniq"
DATE="/bin/date"
TAIL="/usr/bin/tail"
SED="/usr/bin/sed"
UPTIME="/usr/bin/uptime"
WC="/usr/bin/wc -l"
WHO="/usr/bin/who"
RM="/bin/rm"
MAIL="/usr/bin/mail -s"		# MAIL WITH SUBJECT FOR PAGING
set $MAIL
MAILC="$1"
KERMIT="/usr/local/bin/kermit"	# WHERE kermit LIVES
ALPHAPGR="/usr/local/bin/qpage"	# WHERE qpage LIVES
DF="/bin/df"
EXPR="/usr/bin/expr"
HEAD="/usr/bin/head"
CP="/bin/cp"
MV="/bin/mv"
ID="/usr/bin/id"
LN="/bin/ln"
DIG="/usr/bin/dig"
TOP=""
CUT="/usr/bin/cut"
TR="/usr/bin/tr"


AWK=/usr/bin/awk        # Set AWK & GREP paths
EGREP=/usr/bin/egrep    # Make sure your egrep accepts -vx args and
                        # compound expressions (xxx.*|yyy.*|zzz.*disk)
                        # I think by default Solaris doesn't, so use the
			#   one in xpg4 - use bbsys.solaris as bbsys.local

#
# DISK INFORMATION
#
DFSORT="+4"				# % COLUMN - 1
DFUSE="^/dev"				# PATTERN FOR LINES TO INCLUDE
DFEXCLUDE="cdrom"			# PATTERN FOR LINES TO EXCLUDE

#
# PING PARAMETERS
# Added by Gunnar Helliesen <gunnar@bitcon.no> to accomodate different
# styles of ping commands.
#
PINGPAR1="-c 1"
PINGPAR2=""

HEADBYTES="-c "

CUTCHARS="-c"

#
# TOP ARGUMENTS
#
TOPARGS=""
TOPLINES="25"

#
# LOCKFILE PREFIX
# added  by Jacob Lundqvist <jaclu@ibk.se> to handle queued paging
#
LOCKPREFIX="/var/lock/LCK.."

#
#  Lockfile indicating on-going kermit page
#
PAGINGLOCK=${BBTMP}/paginglock

#
# Qpage specific info
# Based on code by Mike Volk <Mike_Volk@pupress.princeton.edu>
#
QPAGE="/usr/local/bin/qpage"
QPAGEUSER="bb"
QPAGEARGS="-f bb"

#
# sendpage specific info
#
SENDPAGE="/usr/local/bin/sendpage"
SENDPAGEARGS=""

#
# LOCAL SYSTEM REDEFINES, BY OS...
#
. ${BBHOME}/etc/bbsys.local

# DFCMD must always appear after DF & SED, so must be after bbsys.local
#  in case they were redefined
# Thanks to Mark.Deiss@acs-gsg.com, bdf output on HP-UX may appear on 2 lines
# For bbsys.sh, the default is that DFCMD is the same as DF
if [ "$DFCMD" = "" ]
then
	DFCMD="$DF"
fi

#
# Define WCC by itself, never define WCC in bbsys.local
#
set $WC
WCC="$1"				# WC without the arguments

#
# MAKE ALL OF THIS AVAILABLE...
#
export PING LS FIND TOUCH CAT GREP SORT UNIQ DATE TAIL SED UPTIME WC WCC WHO RM EXPR HEAD CP MV ID DIG LN TOP CUT TR
export DFCMD AWK EGREP MAIL MAILC KERMIT ALPHAPGR
export DFSORT DFUSE DFEXCLUDE PS NSLOOKUP
export PINGPAR1 PINGPAR2 TOPARGS TOPLINES HEADBYTES CUTCHARS
export LOCKPREFIX PAGINGLOCK
export QPAGE QPAGEUSER QPAGEARGS
export SENDPAGE SENDPAGEARGS
